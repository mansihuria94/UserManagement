insert into Credentials(USER_NAME,PASSWORD)values('mansi','mansi123');
insert into Credentials(USER_NAME,PASSWORD)values('diksha','diksha123');
insert into Credentials(USER_NAME,PASSWORD)values('test','test567');
insert into Credentials(USER_NAME,PASSWORD)values('raghav','rag123');

insert into Employee(ID,AGE,GENDER,NAME)values(1,23,'Female','mansi');
insert into Employee(ID,AGE,GENDER,NAME)values(1,26,'Female','diksha');
insert into Employee(ID,AGE,GENDER,NAME)values(1,27,'Female','test');
insert into Employee(ID,AGE,GENDER,NAME)values(1,23,'Male','raghav');




