package com.honeywell.addingUserInDB.service;

import com.honeywell.addingUserInDB.model.EmployeeRQ;

public interface SaveUserService {
	 boolean saveUser(EmployeeRQ employeeRQ);
}
