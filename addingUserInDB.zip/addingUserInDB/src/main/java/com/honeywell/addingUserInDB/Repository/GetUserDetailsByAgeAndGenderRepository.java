package com.honeywell.addingUserInDB.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.honeywell.addingUserInDB.model.Employee;

@Repository
public interface GetUserDetailsByAgeAndGenderRepository extends CrudRepository<Employee, Integer>  {
	Iterable<Employee> findByAgeBetweenAndGender(int minAge, int maxAge,String gender);

}
