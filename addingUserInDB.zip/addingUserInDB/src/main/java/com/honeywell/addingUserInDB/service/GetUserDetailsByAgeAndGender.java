package com.honeywell.addingUserInDB.service;

import java.util.List;

import com.honeywell.addingUserInDB.model.Employee;


public interface GetUserDetailsByAgeAndGender  {

	List<Employee> findByAgeBetweenAndGender(int minAge, int maxAge,String gender);
	
	
	
}
