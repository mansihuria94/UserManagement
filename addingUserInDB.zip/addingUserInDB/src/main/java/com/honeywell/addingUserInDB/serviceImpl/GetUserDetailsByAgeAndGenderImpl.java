package com.honeywell.addingUserInDB.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeywell.addingUserInDB.Repository.GetUserDetailsByAgeAndGenderRepository;
import com.honeywell.addingUserInDB.model.Employee;
import com.honeywell.addingUserInDB.service.GetUserDetailsByAgeAndGender;

@Service
public class GetUserDetailsByAgeAndGenderImpl implements GetUserDetailsByAgeAndGender {
	@Autowired
	GetUserDetailsByAgeAndGenderRepository getUserDetailsByAgeAndGenderRepository;

	@Override
	public List<Employee> findByAgeBetweenAndGender(int minAge, int maxAge, String gender) {
		// TODO Auto-generated method stub

		Iterable<Employee> it = getUserDetailsByAgeAndGenderRepository.findByAgeBetweenAndGender(minAge, maxAge,
				gender);

		List<Employee> employeeList = StreamSupport.stream(it.spliterator(), false).collect(Collectors.toList());
		return employeeList;
	}

}
