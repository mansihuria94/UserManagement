package com.honeywell.addingUserInDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddingUserInDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddingUserInDbApplication.class, args);
	}

}
