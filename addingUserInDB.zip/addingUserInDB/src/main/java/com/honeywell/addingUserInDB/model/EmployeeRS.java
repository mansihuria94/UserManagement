package com.honeywell.addingUserInDB.model;

public class EmployeeRS {
	private boolean success;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}
}
