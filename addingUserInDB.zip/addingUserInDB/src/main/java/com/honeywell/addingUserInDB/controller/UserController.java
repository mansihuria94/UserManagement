package com.honeywell.addingUserInDB.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.honeywell.addingUserInDB.exception.UserNotFoundException;
import com.honeywell.addingUserInDB.model.Employee;
import com.honeywell.addingUserInDB.model.EmployeeRQ;
import com.honeywell.addingUserInDB.model.EmployeeRS;
import com.honeywell.addingUserInDB.model.LoginRQ;
import com.honeywell.addingUserInDB.model.LoginRS;
import com.honeywell.addingUserInDB.serviceImpl.GetUserDetailsByAgeAndGenderImpl;
import com.honeywell.addingUserInDB.serviceImpl.SaveUserServiceImpl;
import com.honeywell.addingUserInDB.serviceImpl.VerifyUserServiceImpl;

@RestController
public class UserController {

	@Autowired
	private VerifyUserServiceImpl verifyUserServiceImpl;
	@Autowired
	private SaveUserServiceImpl saveUserServiceImpl;
	@Autowired
	private GetUserDetailsByAgeAndGenderImpl getUserDetailsByAgeAndGenderImpl;
	@Autowired
	private HttpServletRequest request;

	@PostMapping("/login")
	public LoginRS verifyUser(@RequestBody LoginRQ loginRQ) {
		Employee employee = null;
		LoginRS loginRS = new LoginRS();
		if (null != loginRQ.getUserName() && null != loginRQ.getPassword()) {
			employee = verifyUserServiceImpl.verifyUser(loginRQ);
		}
		if (null != employee) {
			loginRS.setSuccess(true);
			request.getSession().setAttribute("Employee", employee);
		} else {
			loginRS.setSuccess(false);
		}
		return loginRS;
	}

	@PostMapping("/employee")
	public EmployeeRS addUser(@RequestBody EmployeeRQ employeeRQ) throws UserNotFoundException  {
		Employee employee = (Employee) request.getSession().getAttribute("Employee");
		EmployeeRS employeeRs = new EmployeeRS();
		boolean saveUser = false;
		if (null == employee) {
			throw new UserNotFoundException("User not found in session");
		}
		if (null != employeeRQ) {
			saveUser = saveUserServiceImpl.saveUser(employeeRQ);
		}
		employeeRs.setSuccess(saveUser);
		return employeeRs;
	}

	@GetMapping("/employees")
	public List<Employee> getUser(@RequestParam String gender,
			@RequestParam int minAge, @RequestParam int maxAge) throws UserNotFoundException  {
		Employee employee = (Employee) request.getSession().getAttribute("Employee");
		if (null == employee) {
			throw new UserNotFoundException("User not found in session");
		}
		List<Employee> employeeList = getUserDetailsByAgeAndGenderImpl.findByAgeBetweenAndGender(minAge, maxAge, gender);
		return employeeList;
	}

}
