package com.honeywell.addingUserInDB.service;

import com.honeywell.addingUserInDB.model.Employee;
import com.honeywell.addingUserInDB.model.LoginRQ;

public interface VerifyUserService {
	
	Employee verifyUser(LoginRQ loginRQ);
}
