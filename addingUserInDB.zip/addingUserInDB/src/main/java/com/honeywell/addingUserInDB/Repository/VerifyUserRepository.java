package com.honeywell.addingUserInDB.Repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.honeywell.addingUserInDB.model.Credentials;
@Repository
public interface VerifyUserRepository extends CrudRepository<Credentials,String >{

	public Credentials findByUserNameAndPassword(String userName, String password);

}
