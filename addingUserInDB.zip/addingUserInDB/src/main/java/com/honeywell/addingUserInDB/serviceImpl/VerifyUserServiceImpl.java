package com.honeywell.addingUserInDB.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeywell.addingUserInDB.Repository.EmployeeDetailsRepository;
import com.honeywell.addingUserInDB.Repository.VerifyUserRepository;
import com.honeywell.addingUserInDB.model.Credentials;
import com.honeywell.addingUserInDB.model.Employee;
import com.honeywell.addingUserInDB.model.LoginRQ;
import com.honeywell.addingUserInDB.service.VerifyUserService;

@Service
public class VerifyUserServiceImpl implements VerifyUserService {

	@Autowired
	private VerifyUserRepository verifyUserRepository;
	@Autowired
	EmployeeDetailsRepository employeeDetailsRepository;

	@Override
	public Employee verifyUser(LoginRQ loginRQ) {
		Employee employee = null;
		
		// TODO Auto-generated method stub
		Credentials credentials =  verifyUserRepository
				.findByUserNameAndPassword(loginRQ.getUserName(), loginRQ.getPassword());
		if (null != credentials) {
			employee = employeeDetailsRepository.findByUserName(loginRQ.getUserName());
		}
		return employee;
	}

}
