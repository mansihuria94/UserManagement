package com.honeywell.addingUserInDB.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeywell.addingUserInDB.Repository.SaveUserRepository;
import com.honeywell.addingUserInDB.model.Employee;
import com.honeywell.addingUserInDB.model.EmployeeRQ;
import com.honeywell.addingUserInDB.service.SaveUserService;

@Service
public class SaveUserServiceImpl implements SaveUserService {
	@Autowired
	SaveUserRepository saveUserRepository;

	@Override
	public boolean saveUser(EmployeeRQ employeeRQ) {
		// TODO Auto-generated method stub
		if(null!= employeeRQ) {
			Employee employee = new Employee();
			employee.setAge(employeeRQ.getAge());
			employee.setGender(employeeRQ.getGender());
			employee.setId(employeeRQ.getId());
			employee.setName(employeeRQ.getName());
			saveUserRepository.save(employee);
			return true;
		}
		return false;
	}

}
