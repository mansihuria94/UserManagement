package com.honeywell.addingUserInDB.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.honeywell.addingUserInDB.model.Employee;
@Repository
public interface SaveUserRepository extends CrudRepository<Employee, Integer>{

}
