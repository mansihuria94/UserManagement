/*
 * package com.honeywell.addingUserInDB;
 * 
 * import org.junit.jupiter.api.Test; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * @SpringBootTest class AddingUserInDbApplicationTests {
 * 
 * @Test void contextLoads() { }
 * 
 * }
 */